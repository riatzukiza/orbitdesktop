import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {openProjectRoot} from './project-files.mjs';
import {wbError} from './workbench-store.mjs';

const digest=value=>createHash('sha256').update(value).digest('hex');
// Fixed trusted supervisor. `/usr/bin/timeout` gives every child its own wall-time
// deadline independent of this Node process: if the server is killed, the child
// still terminates instead of leaking a detached job. It is a resource bound,
// NOT a sandbox or isolation mechanism, and it runs under the same UID.
const SUPERVISOR='/usr/bin/timeout';
const TEST_RUNNER=fileURLToPath(new URL('./workbench-test-runner.mjs',import.meta.url));
const TEST_RUNNER_HASH=digest(fs.readFileSync(TEST_RUNNER));
const HOST_SCRIPT=`import {pathToFileURL} from 'node:url';
try {
  const {sum} = await import(pathToFileURL(process.argv[2]).href);
  if (typeof sum !== 'function' || sum(2, 3) !== 5 || sum(-1, 1) !== 0) process.exitCode = 1;
} catch (error) {
  console.error('Host regression failed:', error?.message ?? String(error));
  process.exitCode = 1;
}
`;
// HONEST LIMITS: `logBytes` is the enforced per-run retained artifact cap. There
// is deliberately NO enforced storage quota: the private check directory retains
// at most logBytes, and total disk use is host-limited and same-UID (advisory,
// not a quota). Duration and preview caps likewise bound the supervised command
// and recorder, not arbitrary host resources.
export const CHECK_LIMITS=Object.freeze({durationMs:60000,logBytes:262144,previewBytes:16384,maxConcurrent:1,storage:'advisory: no storage quota is enforced; each run retains at most logBytes in a private directory and total disk use is host-limited'});
export const CHECK_DEFINITIONS=Object.freeze({
  'node-test':Object.freeze({id:'node-test',executable:process.execPath,args:Object.freeze([TEST_RUNNER]),runner_hash:TEST_RUNNER_HASH,result_protocol:1,discovery:'captured **/*.test.{js,cjs,mjs}, **/test/**/*.{js,cjs,mjs}, and test/**/*.test.ts with candidate-local tsx; explicit pinned files v2'}),
  'host-regression':Object.freeze({id:'host-regression',executable:process.execPath,args:Object.freeze([]),script:HOST_SCRIPT}),
});
export function checkDefinition(id){const definition=Object.hasOwn(CHECK_DEFINITIONS,id)?CHECK_DEFINITIONS[id]:undefined;if(!definition)throw wbError('unsupported');return definition;}
export const definitionDigest=definition=>digest(JSON.stringify(definition));
export const checkSpecDigest=fields=>digest(JSON.stringify(fields));
export const discoverTestFiles=files=>files.map(file=>file.path).filter(file=>/(?:^|\/)[^/]+\.test\.(?:js|cjs|mjs)$/.test(file)||/(?:^|\/)test\/.*\.(?:js|cjs|mjs)$/.test(file)||/^test\/.*\.test\.ts$/.test(file)).sort();
export function parseTestResults(buffer,files){
  try{
    if(!Array.isArray(files)||!files.length||files.length>512||new Set(files).size!==files.length)throw Error();
    if(!buffer.length||buffer.length>262144||buffer.at(-1)!==10)throw Error();
    const rows=buffer.toString('utf8').trimEnd().split('\n').map(line=>JSON.parse(line));
    if(rows.length<2)throw Error();
    const counts={tests:0,passed:0,failed:0,skipped:0,todo:0,suites:0};const covered=new Set();let anyFailure=false;
    for(let i=0;i<rows.length;i++){
      const row=rows[i];
      if(row.version!==1||row.sequence!==i)throw Error();
      if(i===0){if(row.type!=='start'||JSON.stringify(row.files)!==JSON.stringify(files)||Object.keys(row).length!==4)throw Error();continue;}
      if(i===rows.length-1){if(row.type!=='end'||Object.keys(row).length!==3)throw Error();continue;}
      if(row.type!=='result'||Object.keys(row).length!==9||!['test','suite'].includes(row.kind)||![row.wrapper,row.passed,row.skip,row.todo].every(value=>typeof value==='boolean')||!(row.file===null||files.includes(row.file)))throw Error();
      if(!row.passed&&!row.todo)anyFailure=true;
      if(row.wrapper)continue;
      if(row.kind==='suite'){counts.suites++;continue;}
      counts.tests++;if(row.skip)counts.skipped++;else if(row.todo)counts.todo++;else if(row.passed){counts.passed++;covered.add(row.file);}else counts.failed++;
    }
    return {version:1,valid:true,...counts,required_files:files,covered_files:[...covered].sort(),complete:files.every(file=>covered.has(file)),success:counts.tests>0&&counts.passed>0&&!anyFailure&&files.every(file=>covered.has(file))};
  }catch{return {version:1,valid:false,success:false,reason:'missing_malformed_or_truncated_results'};}
}

const active=new Map();
const pending=new Set();
export const activeCheckCount=()=>active.size;
// Only an explicit owner acknowledgement may drop uncertain ownership. It does
// not assert termination and never signals an unverified process identity.
export const acknowledgeCheck=job_id=>active.delete(job_id);
function processStart(pid){
  try{const stat=fs.readFileSync(`/proc/${pid}/stat`,'utf8');const fields=stat.slice(stat.lastIndexOf(')')+2).trim().split(/\s+/);return fields[19]??null;}catch{return null;}
}
function signalGroup(pid,signal){try{process.kill(-pid,signal);return true;}catch{return false;}}
function groupAlive(pid){try{process.kill(-pid,0);return true;}catch{return false;}}
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
// Best-effort bounded removal. A supervised command can write an arbitrarily
// large tree through HOME/TMPDIR; an unbounded recursive delete would stall the
// recorder. If the node/time budget is exceeded the remaining private tree is
// retained (job storage is advisory, not a quota) instead of looping forever.
function boundedRemove(root,budgetNodes=4096,deadlineMs=2000){
  const deadline=Date.now()+deadlineMs;let nodes=0,parent;
  const walk=(fd,name,dev,depth)=>{
    if(depth>24||Date.now()>deadline||++nodes>budgetNodes)return false;
    const target=`/proc/self/fd/${fd}/${name}`,before=fs.lstatSync(target);
    if(!before.isDirectory()){fs.unlinkSync(target);return true;}
    const child=fs.openSync(target,fs.constants.O_RDONLY|fs.constants.O_DIRECTORY|fs.constants.O_NOFOLLOW);
    try{
      const opened=fs.fstatSync(child);
      if(opened.dev!==dev||opened.dev!==before.dev||opened.ino!==before.ino)return false;
      const directory=fs.opendirSync(`/proc/self/fd/${child}`);
      try{let entry;while((entry=directory.readSync()))if(!walk(child,entry.name,dev,depth+1))return false;}
      finally{directory.closeSync();}
      const current=fs.lstatSync(target);
      if(current.dev!==opened.dev||current.ino!==opened.ino)return false;
      fs.rmdirSync(target);return true;
    }finally{fs.closeSync(child);}
  };
  try{parent=openProjectRoot(path.dirname(root));return walk(parent.fd,path.basename(root),fs.fstatSync(parent.fd).dev,0);}
  catch{return false;}finally{parent?.close();}
}
// Cancellation is identity-conditional: a reused PID with a different kernel
// start time is never signalled. Returns {requested, confirmed} — confirmed is
// only ever true after the caller observes the actual child exit.
export function cancelCheck({job_id,pid,started_at}){
  const entry=active.get(job_id);
  if(!entry||entry.pid!==pid||entry.started_at!==String(started_at)||processStart(pid)!==entry.started_at)return {requested:false,confirmed:false};
  entry.cancel_requested=true;
  signalGroup(pid,'SIGTERM');
  entry.escalate();
  return {requested:true,confirmed:entry.cancelled===true};
}
function privateRoot(root){
  if(process.platform!=='linux'||typeof root!=='string'||!path.isAbsolute(root)||path.resolve(root)!==root||root==='/'||root.includes('\0'))throw wbError('invalid_request');
  const opened=openProjectRoot(root);
  try{if(!fs.fstatSync(opened.fd).isDirectory())throw wbError('permission_denied');}finally{opened.close();}
}
function validateRoots(candidate,artifacts,boundary=artifacts){
  privateRoot(artifacts);privateRoot(candidate);
  if(boundary!==artifacts){
    // Only the sibling private producer namespace is admitted. No owner/API
    // request contains a root or boundary; execution supplies this trusted value.
    if(path.basename(artifacts)!=='workbench-execution'||path.basename(boundary)!=='workbench-environments'||path.dirname(boundary)!==path.dirname(artifacts))throw wbError('permission_denied');
    privateRoot(boundary);
  }
  if(candidate===boundary||!candidate.startsWith(`${boundary}${path.sep}`))throw wbError('permission_denied');
  if(artifacts.startsWith(`${candidate}${path.sep}`))throw wbError('permission_denied');
}

export async function runCheck(options){
  if(active.size+pending.size>=CHECK_LIMITS.maxConcurrent||pending.has(options?.job_id)||active.has(options?.job_id))throw wbError('busy');
  const reservation=Symbol('check');pending.add(reservation);
  try{return await executeCheck(options);}finally{pending.delete(reservation);}
}
async function executeCheck({definition_id,candidate_root,workspace_id,project_id,job_id,artifact_root,candidate_boundary=artifact_root,rehash,spawn_record,artifact_record,required_test_files=[],provider,provider_identity,execution_backend='trusted_host'}){
  const definition=checkDefinition(definition_id);
  if(execution_backend!=='trusted_host'&&execution_backend!=='gvisor')throw wbError('unsupported');
  if(execution_backend==='gvisor'||provider){
    if(execution_backend!=='gvisor'||provider?.kind!=='gvisor'||typeof provider.spawnCheck!=='function'||!provider.describe().available)throw wbError('unavailable');
    if(definition_id!=='node-test')throw wbError('unsupported');
  }
  if(typeof workspace_id!=='string'||typeof project_id!=='string'||typeof job_id!=='string'||!job_id||typeof rehash!=='function'||typeof spawn_record!=='function')throw wbError('invalid_request');
  validateRoots(candidate_root,artifact_root,candidate_boundary);
  const before=(await rehash())?.hash;
  if(typeof before!=='string'||!before)throw wbError('stale_resource');
  validateRoots(candidate_root,artifact_root,candidate_boundary);
  const definition_digest=definitionDigest(definition);
  const directory=fs.mkdtempSync(path.join(artifact_root,'check-'));fs.chmodSync(directory,0o700);
  const temp=fs.mkdtempSync(path.join(directory,'private-'));fs.chmodSync(temp,0o700);
  const log_path=path.join(directory,'output.log');
  const fd=fs.openSync(log_path,fs.constants.O_WRONLY|fs.constants.O_CREAT|fs.constants.O_EXCL|fs.constants.O_NOFOLLOW,0o600);
  // Lifecycle hook: publish the exact private artifact location and its trusted
  // kernel identity immediately after the exclusive output.log creation, before
  // any child is spawned, so a trusted tail anchors to the recorded inode rather
  // than re-resolving a replaceable path. Purely additive: a rejected or
  // throwing callback never changes the recorder result.
  if(typeof artifact_record==='function')try{
    // BigInt stats give birthtimeNs, the immutable Linux creation identity that
    // survives dev/ino reuse after delete+create. Serialized as decimal strings.
    const logStat=fs.fstatSync(fd,{bigint:true}),dirStat=fs.statSync(directory,{bigint:true}),rootStat=fs.statSync(artifact_root,{bigint:true});
    artifact_record({log_path,artifact_dir:directory,artifact_log_identity:{path:log_path,dev:String(logStat.dev),ino:String(logStat.ino),birthtime_ns:String(logStat.birthtimeNs),dir_dev:String(dirStat.dev),dir_ino:String(dirStat.ino),dir_birthtime_ns:String(dirStat.birthtimeNs),root_dev:String(rootStat.dev),root_ino:String(rootStat.ino),root_birthtime_ns:String(rootStat.birthtimeNs)},definition_id,workspace_id,project_id,job_id,created_at:Date.now()});
  }catch{}
  const env={PATH:'/usr/bin:/bin',HOME:temp,LANG:'C.UTF-8',LC_ALL:'C.UTF-8',NODE_OPTIONS:'',TMPDIR:temp,TSX_DISABLE_CACHE:'1'};
  const env_fingerprint=digest(JSON.stringify(env));
  let args=definition.args;
  if(definition_id==='node-test'){
    if(digest(fs.readFileSync(TEST_RUNNER))!==TEST_RUNNER_HASH)throw wbError('stale_resource');
    args=[TEST_RUNNER,JSON.stringify(required_test_files)];
  }
  if(definition_id==='host-regression'){
    const script=path.join(temp,'verify.mjs');
    fs.writeFileSync(script,HOST_SCRIPT,{mode:0o600,flag:'wx'});
    args=[script,path.join(candidate_root,'math.js')];
  }
  const seconds=Math.max(1,Math.ceil(CHECK_LIMITS.durationMs/1000));
  const supervisedArgs=['--kill-after=1s',`${seconds}s`,definition.executable,...args];
  let command={supervisor:SUPERVISOR,executable:definition.executable,args,supervised:supervisedArgs},providerMetadata={execution_backend:'trusted_host'},providerCleaned=false;
  let child,childStart=null,ended=false,timed_out=false,log_bytes=0,stdout=Buffer.alloc(0),stderr=Buffer.alloc(0),timer,killTimer,hardTimer;
  let results=Buffer.alloc(0),resultsOverflow=false,spawnRecordError=null,recordingError=null,settled;
  const logHash=createHash('sha256');
  const capture=(stream,chunk)=>{
    const remaining=CHECK_LIMITS.previewBytes-(stream==='stdout'?stdout.length:stderr.length);
    if(remaining>0){if(stream==='stdout')stdout=Buffer.concat([stdout,chunk.subarray(0,remaining)]);else stderr=Buffer.concat([stderr,chunk.subarray(0,remaining)]);}
    const room=CHECK_LIMITS.logBytes-log_bytes;
    if(room>0&&!recordingError){
      try{const part=chunk.subarray(0,room);fs.writeSync(fd,part);logHash.update(part);log_bytes+=part.length;}
      catch{recordingError='log_recording_failed';if(childStart&&processStart(child.pid)===childStart)signalGroup(child.pid,'SIGTERM');active.get(job_id)?.escalate();}
    }
  };
  const started_at=Date.now();
  const finish=(extra)=>{
    if(providerMetadata.provider_resource_id){providerCleaned=provider.cleanup(providerMetadata.provider_resource_id);if(!providerCleaned)extra={...extra,process_survival_unknown:true};}
    ended=true;clearTimeout(timer);clearTimeout(killTimer);clearTimeout(hardTimer);if(!extra.process_survival_unknown)active.delete(job_id);
    try{fs.closeSync(fd);}catch{}
    const log_hash=logHash.digest('hex');
    return {...providerMetadata,exit_code:null,signal:null,verdict:'inconclusive',started_at,ended_at:Date.now(),candidate_hash_before:before,candidate_hash_after:before,definition_id,definition_digest,definition_hash:definition_digest,stdout_preview:stdout.toString('utf8'),stderr_preview:stderr.toString('utf8'),log_path,log_hash,log_bytes,artifact_hash:digest(JSON.stringify({log_hash,log_bytes,definition_digest})),env_fingerprint,limits:CHECK_LIMITS,timed_out:false,process_survival_unknown:false,supervisor:SUPERVISOR,command,...extra};
  };
  try{
    const spawnOptions={cwd:candidate_root,env,detached:true,stdio:['ignore','pipe','pipe','pipe'],shell:false,windowsHide:true};
    if(execution_backend==='gvisor'){
      const launched=provider.spawnCheck({candidate_root,runner:TEST_RUNNER,required_test_files,provider_identity,supervisor:SUPERVISOR,seconds,spawnOptions});
      child=launched.child;command=launched.command;providerMetadata=launched.metadata;
    }else child=spawn(SUPERVISOR,supervisedArgs,spawnOptions);
    // Install the error/close listeners IMMEDIATELY. A missing executable emits an
    // asynchronous 'error' event; an unhandled one would crash the host.
    settled=new Promise(resolve=>{
      child.once('error',error=>resolve({code:null,signal:null,error}));
      child.once('close',(code,signal)=>resolve({code,signal,error:null}));
    });
    child.stdout.on('data',chunk=>capture('stdout',chunk));
    child.stderr.on('data',chunk=>capture('stderr',chunk));
    child.stdio[3].on('data',chunk=>{if(results.length+chunk.length>262144){resultsOverflow=true;return;}if(!resultsOverflow)results=Buffer.concat([results,chunk]);});
    const pid=child.pid;
    if(!pid){
      const failure=await settled;
      return finish({spawn_error:'spawn_failed',stderr_preview:String(failure.error?.message??'spawn failed').slice(0,CHECK_LIMITS.previewBytes)});
    }
    childStart=processStart(pid);
    if(!childStart){
      // The child exists but its identity cannot be proven. Never signal a
      // PID/PGID we cannot verify (a reused PID could target an unrelated
      // process); the external supervisor still bounds the command. Report a
      // real unknown, never a pass.
      active.set(job_id,{pid,child,started_at:null,cancel_requested:false,escalate:()=>{}});
      await Promise.race([settled,new Promise(resolve=>{hardTimer=setTimeout(()=>{child.stdout.destroy();child.stderr.destroy();child.stdio[3].destroy();resolve();},CHECK_LIMITS.durationMs+3000);})]);
      return finish({spawn_error:'identity_unavailable',process_survival_unknown:true});
    }
    const entry={pid,child,started_at:childStart,cancelled:false,cancel_requested:false,escalate:()=>{
      if(!killTimer)killTimer=setTimeout(()=>{if(processStart(pid)===childStart)signalGroup(pid,'SIGKILL');},500);
    }};
    active.set(job_id,entry);
    // Durable record is written in the same synchronous turn as spawn, before any
    // child event is awaited, so a crash cannot leave an unrecorded run.
    try{spawn_record({pid,pgid:pid,started_at:childStart,supervisor:SUPERVISOR,command,...providerMetadata});}
    catch{spawnRecordError='spawn_record_failed';if(processStart(pid)===childStart)signalGroup(pid,'SIGTERM');entry.escalate();}
    timer=setTimeout(()=>{timed_out=true;if(processStart(pid)===childStart)signalGroup(pid,'SIGTERM');entry.escalate();},CHECK_LIMITS.durationMs);
    // Hard deadline independent of whether the leader still exists. If a
    // descendant inherited the child's stdio and outlives the leader, the `close`
    // event may never fire; destroying the pipes and resolving guarantees the
    // recorder cannot hang. The lost leader is reported as inconclusive, and no
    // unrelated PID is ever signalled.
    const hardDeadline=new Promise(resolve=>{hardTimer=setTimeout(()=>{timed_out=true;try{child.stdout?.destroy();child.stderr?.destroy();child.stdio[3]?.destroy();}catch{}resolve({code:null,signal:null,error:null,forced:true});},CHECK_LIMITS.durationMs+3000);});
    const result=await Promise.race([settled,hardDeadline]);
    // uutils/GNU timeout exits 124 when the deadline fired.
    if(result.code===124)timed_out=true;
    entry.cancelled=entry.cancelled||entry.cancel_requested;
    clearTimeout(timer);clearTimeout(killTimer);clearTimeout(hardTimer);
    fs.closeSync(fd);ended=true;
    let after;
    try{after=(await rehash())?.hash;}catch{after=null;}
    const log_hash=logHash.digest('hex');
    // The supervisor bounds its own main command while it waits. If the leader
    // exited and a descendant survived in the group, we cannot bound it and must
    // not report a clean pass. If the leader identity still matches we still own
    // the group and may kill it; otherwise we never signal a possibly-reused PGID.
    let process_survival_unknown=result.forced===true;
    if(!process_survival_unknown&&groupAlive(pid)){
      if(processStart(pid)===childStart){
        signalGroup(pid,'SIGKILL');
        for(let i=0;i<20&&groupAlive(pid);i++)await sleep(5);
      }
      if(groupAlive(pid))process_survival_unknown=true;
    }
    if(provider){providerCleaned=provider.cleanup(providerMetadata.provider_resource_id);if(!providerCleaned)process_survival_unknown=true;}
    if(!process_survival_unknown)active.delete(job_id);
    const test_results=definition_id==='node-test'?parseTestResults(resultsOverflow?Buffer.alloc(0):results,required_test_files):null;
    const verdict=recordingError||spawnRecordError||timed_out||entry.cancelled||!after||after!==before||result.error||result.forced||process_survival_unknown?'inconclusive':result.code!==0?'fail':test_results&&!test_results.success?'inconclusive':'pass';
    return {...providerMetadata,exit_code:result.code,signal:result.signal,verdict,cancelled:entry.cancelled,recording_error:recordingError,spawn_error:spawnRecordError,test_results,started_at,ended_at:Date.now(),candidate_hash_before:before,candidate_hash_after:after??null,definition_id,definition_digest,definition_hash:definition_digest,stdout_preview:stdout.toString('utf8'),stderr_preview:stderr.toString('utf8'),log_path,log_hash,log_bytes,artifact_hash:digest(JSON.stringify({log_hash,log_bytes,definition_digest,test_results})),env_fingerprint,limits:CHECK_LIMITS,timed_out,process_survival_unknown,supervisor:SUPERVISOR,command};
  }catch(error){
    if(child?.pid){if(childStart&&processStart(child.pid)===childStart)signalGroup(child.pid,'SIGTERM');setTimeout(()=>{if(childStart&&processStart(child.pid)===childStart)signalGroup(child.pid,'SIGKILL');},500).unref();child.on('error',()=>{});}
    throw error;
  }finally{
    if(providerMetadata.provider_resource_id&&!providerCleaned)provider?.cleanup(providerMetadata.provider_resource_id);
    if(!ended){clearTimeout(timer);clearTimeout(killTimer);clearTimeout(hardTimer);if(!child?.pid)active.delete(job_id);try{fs.closeSync(fd);}catch{}}
    // Bounded best-effort cleanup of the private temp; a huge tree written by the
    // supervised command is left in place rather than stalling the recorder.
    boundedRemove(temp);
  }
}
